    <script src="<?php echo base_url();?>assets/assets_user/js/core/jquery.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/assets_user/js/core/popper.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/assets_user/js/core/bootstrap-material-design.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/assets_user/js/plugins/perfect-scrollbar.jquery.min.js"></script>
    <!--  Google Maps Plugin    -->
    <!-- <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script> -->
    <!-- Chartist JS -->
    <script src="<?php echo base_url();?>assets/assets_user/js/plugins/chartist.min.js"></script>
    <!--  Notifications Plugin    -->
    <script src="<?php echo base_url();?>assets/assets_user/js/plugins/bootstrap-notify.js"></script>
    <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="<?php echo base_url();?>assets/assets_user/js/material-dashboard.min.js?v=2.1.0" type="text/javascript"></script>
    <!-- Material Dashboard DEMO methods, don't include it in your project! -->
    <script src="<?php echo base_url();?>assets/assets_user/demo/demo.js"></script>
       